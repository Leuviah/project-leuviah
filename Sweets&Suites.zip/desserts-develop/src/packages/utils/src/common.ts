export { toBufferBE, toBigIntBE } from "@trufflesuite/bigint-buffer";
