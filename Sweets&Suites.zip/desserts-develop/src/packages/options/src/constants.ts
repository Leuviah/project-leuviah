// Don't change! We need maintain original determinism since the beginning
export const DeterministicSeedPhrase = "TestRPC is awesome!";
