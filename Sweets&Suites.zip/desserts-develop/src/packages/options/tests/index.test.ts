"use strict";

const options = require("..");

describe("@ganache/options", () => {
  it("needs tests");
});
