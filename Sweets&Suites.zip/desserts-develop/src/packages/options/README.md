# `@ganache/options`

Ganache's server/provider options TypeScript types
