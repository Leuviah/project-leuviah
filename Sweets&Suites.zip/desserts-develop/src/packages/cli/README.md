# `@ganache/cli`

> TODO: description
