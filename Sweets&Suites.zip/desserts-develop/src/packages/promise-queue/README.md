# `@ganache/promise-queue`

A queue that resolves Promise instances in first-in first-out order.
