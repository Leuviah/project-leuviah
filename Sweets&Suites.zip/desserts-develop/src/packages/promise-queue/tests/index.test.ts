import assert from "assert";
import PromiseQueue from "..";

describe("@ganache/promise-queue", () => {
  it("needs tests");
});
