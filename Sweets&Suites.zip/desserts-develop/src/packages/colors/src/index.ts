export const TruffleColors = {
  /**
   * Ganache orange
   */
  porsche: "#e4a663",

  /**
   * Truffle blue/turquoise
   */
  turquoise: "#3fe0c5",

  /**
   * Infura orange
   */
  infura: "#ff6b4a"
};
