# `@ganache/colors`

Truffle's colors, hex encoded.

Usage:

```bash
npm install @ganache/truffle-colors
```

```typescript
import { TruffleColors } from "@ganache/truffle-colors";

console.log(TruffleColors.porsche); // #e4a663
console.log(TruffleColors.turquoise); // #3fe0c5
```
