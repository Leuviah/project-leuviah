/*!
 * @ganache/colors
 *
 * @author David Murdoch
 * @license MIT
 */

export * from "./src/index";
