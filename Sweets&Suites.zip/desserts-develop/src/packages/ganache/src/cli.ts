#!/usr/bin/env node

import "@ganache/cli/src/cli";
