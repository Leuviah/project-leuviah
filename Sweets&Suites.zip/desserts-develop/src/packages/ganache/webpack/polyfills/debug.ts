export const debug = () => () => {};
