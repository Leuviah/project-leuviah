import assert from "assert";
import ganache from "..";

describe("@ganache/ganache", () => {
  it("needs tests");
});
