import webpackBrowser from "./webpack/webpack.browser.config";

import webpackNode from "./webpack/webpack.node.config";

export default [webpackBrowser, webpackNode];
