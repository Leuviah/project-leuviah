# `@ganache/secp256k1`

> TODO: description
