import assert from "assert";
import secp256K1 from "../";

describe("@ganache/secp256k1", () => {
  it("needs tests");
});
