enum ContentTypes {
  PLAIN = "text/plain",
  JSON = "application/json"
}
export default ContentTypes;
