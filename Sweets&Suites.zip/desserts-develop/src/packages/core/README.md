# `@ganache/core`

The `@ganache/core` npm package.

See [README.md](../../../README.md) for info.

### Architecture

See [ARCHITECTURE.md](ARCHITECTURE.md)
