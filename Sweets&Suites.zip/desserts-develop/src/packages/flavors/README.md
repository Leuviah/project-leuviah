# `@ganache/flavors`

Ganache's flavors enumeration and TypeScript types
