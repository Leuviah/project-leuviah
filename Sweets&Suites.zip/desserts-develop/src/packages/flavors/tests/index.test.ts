import assert from "assert";

describe("@ganache/flavors", () => {
  it("needs tests");
});
