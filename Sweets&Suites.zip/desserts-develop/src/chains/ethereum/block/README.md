# `@ganache/ethereum-block`

> TODO: description
