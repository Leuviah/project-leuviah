import assert from "assert";

describe("@ganache/ethereum-utils", () => {
  it("needs tests");
});
