# `@ganache/ethereum-utils`

> TODO: description
