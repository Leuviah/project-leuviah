export type WhisperPostObject = any;
