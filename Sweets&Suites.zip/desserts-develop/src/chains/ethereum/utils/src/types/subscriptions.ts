export type SubscriptionId = string;
export type SubscriptionName =
  | "newHeads"
  | "newPendingTransactions"
  | "syncing"
  | "logs";
