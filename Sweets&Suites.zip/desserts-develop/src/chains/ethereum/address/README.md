# `@ganache/ethereum-address`

> TODO: description
