/*!
 * @ganache/console.log
 *
 * @author David Murdoch
 * @license MIT
 */

export { ConsoleLogs, maybeGetLogs } from "./src/maybe-get-logs";
