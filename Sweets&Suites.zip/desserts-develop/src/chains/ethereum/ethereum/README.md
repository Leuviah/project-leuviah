# `@ganache/ethereum`

This is ganache's Ethereum client implementation.
