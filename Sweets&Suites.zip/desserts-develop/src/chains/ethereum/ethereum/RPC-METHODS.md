See our [Interactive Docs](https://ganache.dev/) for a full list of Ganache's RPC methods.
