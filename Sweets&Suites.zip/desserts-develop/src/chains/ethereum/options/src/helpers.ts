export const normalize = <T>(rawInput: T) => rawInput;
