# `@ganache/ethereum-options`

> TODO: description
