# `@ganache/ethereum-transaction`

> TODO: description
