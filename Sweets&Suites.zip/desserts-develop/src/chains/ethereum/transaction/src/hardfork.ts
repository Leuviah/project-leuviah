export type Hardfork =
  | "constantinople"
  | "byzantium"
  | "petersburg"
  | "istanbul"
  | "muirGlacier"
  | "berlin"
  | "london"
  | "arrowGlacier"
  | "grayGlacier"
  | "merge";
