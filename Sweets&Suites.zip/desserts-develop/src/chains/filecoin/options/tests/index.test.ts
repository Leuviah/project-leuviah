import assert from "assert";

describe("@ganache/filecoin-options", () => {
  it("needs tests");
});
