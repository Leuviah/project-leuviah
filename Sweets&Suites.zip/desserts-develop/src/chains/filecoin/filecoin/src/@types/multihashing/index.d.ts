declare module "multihashing";
