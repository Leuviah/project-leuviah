// Reference implementation: https://git.io/JtwmZ
export enum KeyType {
  KeyTypeBLS = "bls",
  KeyTypeSecp256k1 = "secp256k1",
  KeyTypeSecp256k1Ledger = "secp256k1-ledger"
}
