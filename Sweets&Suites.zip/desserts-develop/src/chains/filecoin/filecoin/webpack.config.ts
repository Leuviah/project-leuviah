import webpackNode from "./webpack/webpack.node.config";

export default [webpackNode];
