import assert from "assert";
import tezosOptions from "../src/";

describe("@ganache/tezos-options", () => {
  it("needs tests");
});
