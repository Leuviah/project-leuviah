# `@ganache/tezos-options`

> TODO: description
