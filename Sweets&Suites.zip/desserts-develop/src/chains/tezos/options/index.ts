/*!
 * @ganache/tezos-options
 *
 * @author David Murdoch <david@trufflesuite.com> (https://davidmurdoch.com)
 * @license MIT
 */

export default {
  // TODO
};
