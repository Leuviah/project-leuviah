"use strict";

const tezos = require("..");

describe("@ganache/tezos", () => {
  it("needs tests");
});
