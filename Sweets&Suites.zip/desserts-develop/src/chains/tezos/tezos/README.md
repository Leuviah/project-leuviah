# `@ganache/tezos`

This is ganache's Tezos client implementation.
